package com.knf.dev.librarymanagementsystem.vo;

public record PublisherRecord(Long id, String name) {

}
